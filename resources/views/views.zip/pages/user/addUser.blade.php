@extends('layouts.app')

@section('headscript')
<script src="https://code.jquery.com/jquery-3.4.1.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.2.3/css/responsive.bootstrap4.min.css">
<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/responsive/2.2.3/js/dataTables.responsive.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/responsive/2.2.3/js/responsive.bootstrap4.min.js"></script>
@endsection

@section('style')
<style media="screen">
.dataTables_filter {
  text-align: left !important;
}
</style>
@endsection

@section('content')
<div class="container">
  @if ($checkAdmin == 'admin' && $activeCount >= 1)
    <div class="row justify-content-center" style="margin-bottom:20px;">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    Pending system activation request : <a href="{{ route('user-activation') }}" style="text-decoration:none;">{{$activeCount}} User waiting</a>
                </div>
            </div>
        </div>
    </div>
  @else

  @endif

    <div class="row">
          <div class="col-md-9">
            <div class="card">
              <div class="card-header">
                <h1>Add New User Page</h1>
              </div>
              <div class="card-body">
                <div>
                  <form method="POST" action="{{ route('user.store') }}">
                      @csrf

                        <div class="form-group row">
                          <div class="col-md-2">
                          </div>
                          <div class="col-md-4">
                              <input id="firstname" type="text" class="form-control @error('firstname') is-invalid @enderror" name="firstname" value="{{ old('firstname') }}" required autocomplete="firstname" placeholder="First Name"  onkeyup="this.value = this.value.toUpperCase();" autofocus>

                              @error('firstname')
                                  <span class="invalid-feedback" role="alert">
                                      <strong>{{ $message }}</strong>
                                  </span>
                              @enderror
                          </div>
                          <div class="col-md-4">
                              <input id="lastname" type="text" class="form-control @error('lastname') is-invalid @enderror" name="lastname" value="{{ old('lastname') }}"  autocomplete="lastname" required placeholder="Last Name"  onkeyup="this.value = this.value.toUpperCase();" autofocus>

                              @error('lastname')
                                  <span class="invalid-feedback" role="alert">
                                      <strong>{{ $message }}</strong>
                                  </span>
                              @enderror
                          </div>
                          <div class="col-md-2">
                          </div>
                      </div>

                      <div class="form-group row">
                        <div class="col-md-2">
                        </div>
                          <div class="col-md-8">
                              <input id="email" type="email" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}" required autocomplete="email" placeholder="Email">

                              @error('email')
                                  <span class="invalid-feedback" role="alert">
                                      <strong>{{ $message }}</strong>
                                  </span>
                              @enderror
                          </div>
                      </div>

                      <div class="form-group row">
                        <div class="col-md-2">
                        </div>
                          <div class="col-md-8">
                              <input id="username" type="text" class="form-control @error('username') is-invalid @enderror" name="username" value="{{ old('username') }}" required autocomplete="username"  onkeyup="this.value = this.value.toUpperCase();" placeholder="Username">

                              @error('username')
                                  <span class="invalid-feedback" role="alert">
                                      <strong>{{ $message }}</strong>
                                  </span>
                              @enderror
                          </div>
                      </div>

                      <div class="form-group row">
                        <div class="col-md-2">
                        </div>
                        <div class="col-md-8">
                          <select id="position" class="form-control @error('position') is-invalid @enderror" name="position">
                            <option selected="true" disabled="disabled">Position</option>
                            <option value="EXECUTIVE">Executive</option>
                            <option value="DRIVER">Driver</option>
                          </select>

                          @error('position')
                              <span class="invalid-feedback" role="alert">
                                  <strong>{{ $message }}</strong>
                              </span>
                          @enderror
                        </div>
                      </div>

                      <div class="form-group row">
                        <div class="col-md-2">
                        </div>
                        <div class="col-md-8">
                          <select id="role" class="form-control @error('role') is-invalid @enderror" name="role">
                            <option selected="true" disabled="disabled">Role</option>
                            <option value="ADMIN">Admin</option>
                            <option value="USER">Normal User</option>
                          </select>

                          @error('role')
                              <span class="invalid-feedback" role="alert">
                                  <strong>{{ $message }}</strong>
                              </span>
                          @enderror
                        </div>
                      </div>

                      <div class="form-group row">
                          <div class="col-md-2">
                          </div>
                          <div class="col-md-4">
                              <button type="submit" class="btn btn-success form-control"><i class="fa fa-user-plus"></i> Add New User</button>
                          </div>
                          <div class="col-md-4">
                              <a href="{{ route('user.index') }}" class="btn btn-danger form-control"><i class="fa fa-user-times"></i> Cancel</a>
                          </div>
                          <div class="col-md-2">
                          </div>
                      </div>

                  </form>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-3">
            <div class="card">
                <div class="card-header">Task List</div>

                <div class="card-body">
                  @if(count($task) === 0)
                    <a href="{{ route('task.create') }}" style="text-decoration:none;"><i class="fas fa-plus-circle"></i> Add Task</a>
                  @else
                    @foreach ($task as $row)
                      <a href="#" style="text-decoration: none;">{{ $row->subject }}</a>
                      <hr>
                    @endforeach
                    <a href="{{ route('task.index') }}" style="text-decoration: none;float: right;"><i class="fas fa-chevron-circle-right"></i> Full Task List</a>
                  @endif
                </div>
            </div>
          </div>
    </div>
</div>


@endsection

@section('script')
@endsection
