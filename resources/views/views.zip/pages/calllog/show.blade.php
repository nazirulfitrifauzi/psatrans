@extends('layouts.app')

@section('headscript')
<script src="https://code.jquery.com/jquery-3.4.1.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.2.3/css/responsive.bootstrap4.min.css">
<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/responsive/2.2.3/js/dataTables.responsive.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/responsive/2.2.3/js/responsive.bootstrap4.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.6/js/dataTables.buttons.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.6/js/buttons.html5.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.6/js/buttons.print.min.js"></script>
@endsection

@section('style')
<style media="screen">
.dataTables_filter {
  text-align: left !important;
}
.header{
  color: #fff;
  background-color: #212529;
  border-color: #32383e;
}
.required{
  color: red;
}
.remark{
  background-color: lightgray;
  padding: 10px;
  border-radius: 5px;
}
</style>
@endsection

@section('content')
<div class="container">
  @if ($checkAdmin == 'admin')
    @if ($activeCount >= 1 || $countpriority >= 1)
      <div class="row justify-content-center" style="margin-bottom:20px;">
          <div class="col-md-12">
              <div class="card">
                  <div class="card-body">
                    @if($countpriority > 1)
                      <i class="fas fa-exclamation-triangle required"></i> <a href="{{ route('task.index') }}" style="text-decoration:none;"> <b style="color:black;">{{ $countpriority }} URGENT Task <span class="required">(Priority 5)</span> waiting to be resolved!</b></a>
                      <br>
                    @elseif($countpriority == 1)
                      @foreach ($priority as $tasknoti)
                        <i class="fas fa-exclamation-triangle required"></i> <b>URGENT: {{$tasknoti->subject}} <span class="required">(Priority {{$tasknoti->priority}})</span></b>
                        <br>
                      @endforeach
                    @else
                    @endif

                    @if($activeCount >= 1)
                      Pending system activation request : <a href="{{ route('user-activation') }}" style="text-decoration:none;">{{$activeCount}} User waiting</a>
                    @else

                    @endif
                  </div>
              </div>
          </div>
      </div>
    @else

    @endif

  @else

  @endif

    <div class="row">
          <div class="col-md-9">
            <div class="card">
              <div class="card-header">
                <h1>Call Log Page</h1>
              </div>
              <div class="card-body">
                <div>
                  <form class="col-md-12" action="/call/{{ $calldata->id }}" method="post">
                    @method('PATCH')
                    @csrf

                    <div class="form-group row">
                      <div class="col-md-6">
                        <b>Contact Name:</b> <br> {{ $calldata->contact_name }}
                      </div>
                      <div class="col-md-6">
                        <b>Contact No:</b> <br> {{ $calldata->contact_no }}
                      </div>
                    </div>

                    <div class="form-group row">
                      <div class="col-md-12">
                        <b>Subject:</b> <br> {{ $calldata->subject }}
                      </div>
                    </div>

                    <div class="form-group row">
                      <div class="col-md-12">
                        <b>Description:</b> <br>
                        <span>{{ $calldata->description }}</span>
                      </div>
                    </div>

                    <div class="form-group row remark">
                      <div class="col-md-12">
                        <b>Remarks:</b> <br>
                          @if (count($remarks) > 0)
                            <table class="table-sm">
                              <tbody>
                                  @foreach ($remarks as $row)
                                  <tr>
                                    <td>{{ $row->datetime->format('d-m-Y') }} ( {{ $row->datetime->format('h:i A') }} )</td>
                                    <td> : </td>
                                    <td>{{ $row->remark }}</td>
                                  </tr>
                                  @endforeach
                              </tbody>
                            </table>
                          @else
                          @endif

                          <input id="remark" type="text" class="form-control" name="remark" placeholder="Add Remark">
                      </div>
                    </div>

                    <div class="form-group row">
                      <div class="col-md-12">
                        <div class="form-group">
                          <label for="status"><b>Status: </b></label>

                          <div class="input-group">
                            <select name="status" class="form-control input-sm" id="status">
                              <option value="I" @if($calldata->status == 'I') selected @endif >In-progress</option>
                              <option value="C" @if($calldata->status == 'C') selected @endif>Completed</option>
                              <option value="X" @if($calldata->status == 'X') selected @endif>Close</option>
                            </select>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-md-2">
                        </div>
                        <div class="col-md-4">
                            <button type="submit" class="btn btn-success form-control"><i class="fa fa-user-plus"></i> Update</button>
                        </div>
                        <div class="col-md-4">
                            <a href="{{ route('call.index') }}" class="btn btn-danger form-control"><i class="fa fa-user-times"></i> Cancel</a>
                        </div>
                        <div class="col-md-2">
                        </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-3">
            <div class="card">
                <div class="card-header">Task List</div>

                <div class="card-body">
                  @if(count($task) === 0)
                    <a href="{{ route('task.create') }}" style="text-decoration:none;"><i class="fas fa-plus-circle"></i> Add Task</a>
                  @else
                    @foreach ($task as $row)
                      <a href="#" style="text-decoration: none;">{{ $row->subject }}</a>
                      <hr>
                    @endforeach
                    <a href="{{ route('task.index') }}" style="text-decoration: none;float: right;"><i class="fas fa-chevron-circle-right"></i> Full Task List</a>
                  @endif
                </div>
            </div>
          </div>
    </div>
</div>

@endsection

@section('script')
<script type="text/javascript">
$(document).ready(function() {

const Toast = Swal.mixin({
  toast: true,
  position: 'bottom-end',
  showConfirmButton: false,
  timer: 5000
});

@if(\Session::has('error'))
  Toast.fire({
    type: 'error',
    title: '{{ \Session::get('error') }}'
  })
@elseif(\Session::has('success'))
  Toast.fire({
    type: 'success',
    title: '{{ \Session::get('success') }}'
  })
@endif
});
</script>
@endsection
