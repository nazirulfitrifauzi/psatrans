@extends('layouts.app')

@section('headscript')
<script src="https://code.jquery.com/jquery-3.4.1.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.2.3/css/responsive.bootstrap4.min.css">
<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/responsive/2.2.3/js/dataTables.responsive.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/responsive/2.2.3/js/responsive.bootstrap4.min.js"></script>
@endsection

@section('style')
<style media="screen">
.dataTables_filter {
  text-align: left !important;
}
.required{
  color: red;
}
</style>
@endsection

@section('content')
<div class="container">
  @if ($checkAdmin == 'admin')
    @if ($activeCount >= 1 || $countpriority >= 1)
      <div class="row justify-content-center" style="margin-bottom:20px;">
          <div class="col-md-12">
              <div class="card">
                  <div class="card-body">
                    @if($countpriority > 1)
                      <i class="fas fa-exclamation-triangle required"></i> <a href="{{ route('task.index') }}" style="text-decoration:none;"> <b style="color:black;">{{ $countpriority }} URGENT Task <span class="required">(Priority 5)</span> waiting to be resolved!</b></a>
                      <br>
                    @elseif($countpriority == 1)
                      @foreach ($priority as $tasknoti)
                        <i class="fas fa-exclamation-triangle required"></i> <b>URGENT: {{$tasknoti->subject}} <span class="required">(Priority {{$tasknoti->priority}})</span></b>
                        <br>
                      @endforeach
                    @else
                    @endif

                    @if($activeCount >= 1)
                      Pending system activation request : <a href="{{ route('user-activation') }}" style="text-decoration:none;">{{$activeCount}} User waiting</a>
                    @else

                    @endif
                  </div>
              </div>
          </div>
      </div>
    @else

    @endif

  @else

  @endif

    <div class="row">
          <div class="col-md-9">
            <div class="card">
              <div class="card-header">
                <h1>Company Setup Page</h1>
              </div>
              <div class="card-body">
                <div>
                      <div class="form-group row">
                          <label for="companyname" class="col-md-2 col-form-label text-md-right">Company Name</label>

                          <div class="col-md-10">
                              <input id="companyname" type="text" class="form-control @error('companyname') is-invalid @enderror" name="companyname" value="{{ $company->company_name }}" required autocomplete="companyname" autofocus disabled>
                          </div>
                      </div>

                      <div class="form-group row">
                          <label for="registration" class="col-md-2 col-form-label text-md-right">Registration ID</label>

                          <div class="col-md-4">
                              <input id="registration" type="text" class="form-control @error('registration') is-invalid @enderror" name="registration" value="{{ $company->registration_id }}" required autocomplete="registration" autofocus disabled>
                          </div>

                          <label for="gst" class="col-md-2 col-form-label text-md-right">GST ID</label>

                          <div class="col-md-4">
                              <input id="gst" type="text" class="form-control @error('gst') is-invalid @enderror" name="gst" value="{{ $company->gst_id }}" required autocomplete="gst" autofocus disabled>
                          </div>
                      </div>

                      <div class="form-group row">
                          <label for="address1" class="col-md-2 col-form-label text-md-right">Address 1</label>

                          <div class="col-md-10">
                              <input id="address1" type="text" class="form-control @error('address1') is-invalid @enderror" name="address1" value="{{ $company->address1 }}" required autocomplete="address1" autofocus disabled>
                          </div>
                      </div>

                      <div class="form-group row">
                          <label for="address2" class="col-md-2 col-form-label text-md-right">Address 2</label>

                          <div class="col-md-10">
                              <input id="address2" type="text" class="form-control @error('address2') is-invalid @enderror" name="address2" value="{{ $company->address2 }}" autocomplete="address2" autofocus disabled>
                          </div>
                      </div>

                      <div class="form-group row">
                          <label for="city" class="col-md-2 col-form-label text-md-right">City</label>

                          <div class="col-md-4">
                              <input id="city" type="text" class="form-control @error('city') is-invalid @enderror" name="city" value="{{ $company->city }}" required autocomplete="city" autofocus disabled>
                          </div>

                          <label for="state" class="col-md-2 col-form-label text-md-right">State</label>

                          <div class="col-md-4">
                              <input id="state" type="text" class="form-control @error('state') is-invalid @enderror" name="state" value="{{ $company->state }}" required autocomplete="state" autofocus disabled>
                          </div>
                      </div>

                      <div class="form-group row">
                          <label for="postcode" class="col-md-2 col-form-label text-md-right">Postcode</label>

                          <div class="col-md-4">
                              <input id="postcode" type="text" class="form-control @error('postcode') is-invalid @enderror" name="postcode" value="{{ $company->post_code }}" required autocomplete="postcode" autofocus disabled>
                          </div>

                          <label for="country" class="col-md-2 col-form-label text-md-right">Country</label>

                          <div class="col-md-4">
                              <input id="country" type="text" class="form-control @error('country') is-invalid @enderror" name="country" value="{{ $company->country }}" required autocomplete="country" autofocus disabled>
                          </div>
                      </div>

                      <div class="form-group row">
                          <label for="telephone" class="col-md-2 col-form-label text-md-right">Telephone</label>

                          <div class="col-md-4">
                              <input id="telephone" type="text" class="form-control @error('telephone') is-invalid @enderror" name="telephone" value="{{ $company->telephone }}" required autocomplete="telephone" autofocus disabled>
                          </div>

                          <label for="fax" class="col-md-2 col-form-label text-md-right">Fax</label>

                          <div class="col-md-4">
                              <input id="fax" type="text" class="form-control @error('fax') is-invalid @enderror" name="fax" value="{{ $company->fax }}" required autocomplete="fax" autofocus disabled>
                          </div>
                      </div>

                      <div class="form-group row">
                          <label for="email" class="col-md-2 col-form-label text-md-right">Email</label>

                          <div class="col-md-10">
                              <input id="email" type="text" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ $company->email }}" autocomplete="email" autofocus disabled>
                          </div>
                      </div>

                      <div class="form-group row">
                          <div class="col-md-2">
                          </div>
                          <div class="col-md-8">
                              <a href="company-setup/{{ $company->id }}/edit" class="btn btn-success form-control"><i class="fa fa-edit"></i> Edit</a>
                          </div>
                          <div class="col-md-2">
                          </div>
                      </div>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-3">
            <div class="card">
                <div class="card-header">Task List</div>

                <div class="card-body">
                  @if(count($task) === 0)
                    <a href="{{ route('task.create') }}" style="text-decoration:none;"><i class="fas fa-plus-circle"></i> Add Task</a>
                  @else
                    @foreach ($task as $row)
                      <a href="#" style="text-decoration: none;">{{ $row->subject }}</a>
                      <hr>
                    @endforeach
                    <a href="{{ route('task.index') }}" style="text-decoration: none;float: right;"><i class="fas fa-chevron-circle-right"></i> Full Task List</a>
                  @endif
                </div>
            </div>
          </div>
    </div>
</div>

@endsection

@section('script')
<script type="text/javascript">
$(document).ready(function() {

     window.setTimeout(function() {
       $(".alert").fadeTo(500, 0).slideUp(500, function(){
         $(this).remove();
       });
     }, 4000);

});

const Toast = Swal.mixin({
  toast: true,
  position: 'bottom-end',
  showConfirmButton: false,
  timer: 5000
});

@if(\Session::has('error'))
  Toast.fire({
    type: 'error',
    title: '{{ \Session::get('error') }}'
  })
@elseif(\Session::has('success'))
  Toast.fire({
    type: 'success',
    title: '{{ \Session::get('success') }}'
  })
@endif
</script>
@endsection
