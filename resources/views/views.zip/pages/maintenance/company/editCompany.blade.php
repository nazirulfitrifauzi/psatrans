@extends('layouts.app')

@section('headscript')
<script src="https://code.jquery.com/jquery-3.4.1.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.2.3/css/responsive.bootstrap4.min.css">
<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/responsive/2.2.3/js/dataTables.responsive.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/responsive/2.2.3/js/responsive.bootstrap4.min.js"></script>
@endsection

@section('style')
<style media="screen">
.dataTables_filter {
  text-align: left !important;
}
.required{
  color: red;
}
</style>
@endsection

@section('content')
<div class="container" style="position:relative;">
  @if ($checkAdmin == 'admin')
    @if ($activeCount >= 1 || $countpriority >= 1)
      <div class="row justify-content-center" style="margin-bottom:20px;">
          <div class="col-md-12">
              <div class="card">
                  <div class="card-body">
                    @if($countpriority > 1)
                      <i class="fas fa-exclamation-triangle required"></i> <a href="{{ route('task.index') }}" style="text-decoration:none;"> <b style="color:black;">{{ $countpriority }} URGENT Task <span class="required">(Priority 5)</span> waiting to be resolved!</b></a>
                      <br>
                    @elseif($countpriority == 1)
                      @foreach ($priority as $tasknoti)
                        <i class="fas fa-exclamation-triangle required"></i> <b>URGENT: {{$tasknoti->subject}} <span class="required">(Priority {{$tasknoti->priority}})</span></b>
                        <br>
                      @endforeach
                    @else
                    @endif

                    @if($activeCount >= 1)
                      Pending system activation request : <a href="{{ route('user-activation') }}" style="text-decoration:none;">{{$activeCount}} User waiting</a>
                    @else

                    @endif
                  </div>
              </div>
          </div>
      </div>
    @else

    @endif

  @else

  @endif

    <div class="row">
          <div class="col-md-9">
            <div class="card">
              <div class="card-header">
                <h1>Company Setup Page</h1>
              </div>
              <div class="card-body">
                <div>
                  <form action="/company-setup/{{ $company->id }}" method="post">
                    @method('PATCH')
                    @csrf

                    <div class="form-group row">
                          <label for="company_name" class="col-md-3 col-form-label text-md-right"><span class="required">* </span>Company Name</label>

                          <div class="col-md-9">
                              <input id="company_name" type="text" class="form-control @error('company_name') is-invalid @enderror" name="company_name" value="{{ $company->company_name }}" required autocomplete="company_name" autofocus>

                              @error('company_name')
                                  <span class="invalid-feedback" role="alert">
                                      <strong>{{ $message }}</strong>
                                  </span>
                              @enderror
                          </div>
                      </div>

                      <div class="form-group row">
                          <label for="registration_id" class="col-md-3 col-form-label text-md-right"><span class="required">* </span>Registration ID</label>

                          <div class="col-md-3">
                              <input id="registration_id" type="text" class="form-control @error('registration_id') is-invalid @enderror" name="registration_id" value="{{ $company->registration_id }}" required autocomplete="registration_id" autofocus>

                              @error('registration_id')
                                  <span class="invalid-feedback" role="alert">
                                      <strong>{{ $message }}</strong>
                                  </span>
                              @enderror
                          </div>

                          <label for="gst_id" class="col-md-2 col-form-label text-md-right"><span class="required">* </span>GST ID</label>

                          <div class="col-md-4">
                              <input id="gst_id" type="text" class="form-control @error('gst_id') is-invalid @enderror" name="gst_id" value="{{ $company->gst_id }}" required autocomplete="gst_id" autofocus>

                              @error('gst_id')
                                  <span class="invalid-feedback" role="alert">
                                      <strong>{{ $message }}</strong>
                                  </span>
                              @enderror
                          </div>
                      </div>

                      <div class="form-group row">
                          <label for="address1" class="col-md-3 col-form-label text-md-right"><span class="required">* </span>Address 1</label>

                          <div class="col-md-9">
                              <input id="address1" type="text" class="form-control @error('address1') is-invalid @enderror" name="address1" value="{{ $company->address1 }}" required autocomplete="address1" autofocus>

                              @error('address1')
                                  <span class="invalid-feedback" role="alert">
                                      <strong>{{ $message }}</strong>
                                  </span>
                              @enderror
                          </div>
                      </div>

                      <div class="form-group row">
                          <label for="address2" class="col-md-3 col-form-label text-md-right">Address 2</label>

                          <div class="col-md-9">
                              <input id="address2" type="text" class="form-control @error('address2') is-invalid @enderror" name="address2" value="{{ $company->address2 }}" autocomplete="address2" autofocus>
                          </div>
                      </div>

                      <div class="form-group row">
                          <label for="city" class="col-md-3 col-form-label text-md-right"><span class="required">* </span>City</label>

                          <div class="col-md-3">
                              <input id="city" type="text" class="form-control @error('city') is-invalid @enderror" name="city" value="{{ $company->city }}" required autocomplete="city" autofocus>

                              @error('city')
                                  <span class="invalid-feedback" role="alert">
                                      <strong>{{ $message }}</strong>
                                  </span>
                              @enderror
                          </div>

                          <label for="state" class="col-md-2 col-form-label text-md-right"><span class="required">* </span>State</label>

                          <div class="col-md-4">
                              <input id="state" type="text" class="form-control @error('state') is-invalid @enderror" name="state" value="{{ $company->state }}" required autocomplete="state" autofocus>

                              @error('state')
                                  <span class="invalid-feedback" role="alert">
                                      <strong>{{ $message }}</strong>
                                  </span>
                              @enderror
                          </div>
                      </div>

                      <div class="form-group row">
                          <label for="post_code" class="col-md-3 col-form-label text-md-right"><span class="required">* </span>Postcode</label>

                          <div class="col-md-3">
                              <input id="post_code" type="text" class="form-control @error('post_code') is-invalid @enderror" name="post_code" value="{{ $company->post_code }}" required autocomplete="post_code" autofocus>

                              @error('post_code')
                                  <span class="invalid-feedback" role="alert">
                                      <strong>{{ $message }}</strong>
                                  </span>
                              @enderror
                          </div>

                          <label for="country" class="col-md-2 col-form-label text-md-right"><span class="required">* </span>Country</label>

                          <div class="col-md-4">
                              <input id="country" type="text" class="form-control @error('country') is-invalid @enderror" name="country" value="{{ $company->country }}" required autocomplete="country" autofocus>

                              @error('country')
                                  <span class="invalid-feedback" role="alert">
                                      <strong>{{ $message }}</strong>
                                  </span>
                              @enderror
                          </div>
                      </div>

                      <div class="form-group row">
                          <label for="telephone" class="col-md-3 col-form-label text-md-right"><span class="required">* </span>Telephone</label>

                          <div class="col-md-3">
                              <input id="telephone" type="text" class="form-control @error('telephone') is-invalid @enderror" name="telephone" value="{{ $company->telephone }}" required autocomplete="telephone" autofocus>

                              @error('telephone')
                                  <span class="invalid-feedback" role="alert">
                                      <strong>{{ $message }}</strong>
                                  </span>
                              @enderror
                          </div>

                          <label for="fax" class="col-md-2 col-form-label text-md-right">Fax</label>

                          <div class="col-md-4">
                              <input id="fax" type="text" class="form-control @error('fax') is-invalid @enderror" name="fax" value="{{ $company->fax }}" required autocomplete="fax" autofocus>

                              @error('fax')
                                  <span class="invalid-feedback" role="alert">
                                      <strong>{{ $message }}</strong>
                                  </span>
                              @enderror
                          </div>
                      </div>

                      <div class="form-group row">
                          <label for="email" class="col-md-3 col-form-label text-md-right">Email</label>

                          <div class="col-md-9">
                              <input id="email" type="text" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ $company->email }}" autocomplete="email" autofocus>

                              @error('email')
                                  <span class="invalid-feedback" role="alert">
                                      <strong>{{ $message }}</strong>
                                  </span>
                              @enderror
                          </div>
                      </div>

                      <div class="form-group row">
                          <div class="col-md-2">
                          </div>
                              <button class="col-md-4 btn btn-success" type="submit"><i class="fa fa-check"></i> Update</button>
                              &nbsp;
                              <a class="col-md-4 btn btn-danger" href="/company-setup"><i class="fa fa-times"></i> Cancel</a>
                          <div class="col-md-2">
                          </div>
                      </div>


                  </form>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-3">
            <div class="card">
                <div class="card-header">Task List</div>

                <div class="card-body">
                  @if(count($task) === 0)
                    <a href="{{ route('task.create') }}" style="text-decoration:none;"><i class="fas fa-plus-circle"></i> Add Task</a>
                  @else
                    @foreach ($task as $row)
                      <a href="#" style="text-decoration: none;">{{ $row->subject }}</a>
                      <hr>
                    @endforeach
                    <a href="{{ route('task.index') }}" style="text-decoration: none;float: right;"><i class="fas fa-chevron-circle-right"></i> Full Task List</a>
                  @endif
                </div>
            </div>
          </div>
    </div>
</div>


@endsection
