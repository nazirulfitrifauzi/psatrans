@extends('layouts.app')

@section('headscript')
<script src="https://code.jquery.com/jquery-3.4.1.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.2.3/css/responsive.bootstrap4.min.css">
<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/responsive/2.2.3/js/dataTables.responsive.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/responsive/2.2.3/js/responsive.bootstrap4.min.js"></script>
@endsection

@section('style')
<style media="screen">
.dataTables_filter {
  text-align: left !important;
}
.required{
  color: red;
}
</style>
@endsection

@section('content')
<div class="container">
  @if ($checkAdmin == 'admin')
    @if ($activeCount >= 1 || $countpriority >= 1)
      <div class="row justify-content-center" style="margin-bottom:20px;">
          <div class="col-md-12">
              <div class="card">
                  <div class="card-body">
                    @if($countpriority > 1)
                      <i class="fas fa-exclamation-triangle required"></i> <a href="{{ route('task.index') }}" style="text-decoration:none;"> <b style="color:black;">{{ $countpriority }} URGENT Task <span class="required">(Priority 5)</span> waiting to be resolved!</b></a>
                      <br>
                    @elseif($countpriority == 1)
                      @foreach ($priority as $tasknoti)
                        <i class="fas fa-exclamation-triangle required"></i> <b>URGENT: {{$tasknoti->subject}} <span class="required">(Priority {{$tasknoti->priority}})</span></b>
                        <br>
                      @endforeach
                    @else
                    @endif

                    @if($activeCount >= 1)
                      Pending system activation request : <a href="{{ route('user-activation') }}" style="text-decoration:none;">{{$activeCount}} User waiting</a>
                    @else

                    @endif
                  </div>
              </div>
          </div>
      </div>
    @else

    @endif

  @else

  @endif

    <div class="row">
          <div class="col-md-9">
            <div class="card">
              <div class="card-header">
                <h1> Add Shipping Account Page</h1>
              </div>
              <div class="card-body">
                <div>
                  <form method="POST" action="{{ route('shipping.store') }}">
                    @csrf

                    <div class="form-group row">
                        <label for="shipper_code" class="col-md-2 col-form-label text-md-right"><span class="required">* </span>Shipper Code</label>

                        <div class="col-md-5 input-group">
                          <input id="shipper_code" type="text" class="form-control @error('shipper_code') is-invalid @enderror" name="shipper_code"  onkeyup="this.value = this.value.toUpperCase();" required>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="shipper_name" class="col-md-2 col-form-label text-md-right"><span class="required">* </span>Shipper Name</label>

                        <div class="col-md-10 input-group">
                          <input id="shipper_name" type="text" class="form-control @error('shipper_name') is-invalid @enderror" value=""  onkeyup="this.value = this.value.toUpperCase();" name="shipper_name" required>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="gst_id" class="col-md-2 col-form-label text-md-right"><span class="required">* </span>GST ID</label>

                        <div class="col-md-10 input-group">
                          <input id="gst_id" type="text" class="form-control @error('gst_id') is-invalid @enderror" value="" name="gst_id" required >
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="address1" class="col-md-2 col-form-label text-md-right"><span class="required">* </span>Address</label>

                        <div class="col-md-10 input-group">
                          <input id="address1" type="text" class="form-control @error('address1') is-invalid @enderror" value="" name="address1"  onkeyup="this.value = this.value.toUpperCase();" required >
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="address2" class="col-md-2 col-form-label text-md-right"></label>

                        <div class="col-md-10 input-group">
                          <input id="address2" type="text" class="form-control @error('address2') is-invalid @enderror" value="" onkeyup="this.value = this.value.toUpperCase();" name="address2">
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="city" class="col-md-2 col-form-label text-md-right"><span class="required">* </span>City</label>

                        <div class="col-md-4 input-group">
                          <input id="city" type="text" class="form-control @error('city') is-invalid @enderror" value=""  onkeyup="this.value = this.value.toUpperCase();" name="city" required>
                        </div>

                        <label for="state" class="col-md-2 col-form-label text-md-right"><span class="required">* </span>State</label>

                        <div class="col-md-4 input-group">
                          <input id="state" type="text" class="form-control @error('state') is-invalid @enderror" value="" name="state"  onkeyup="this.value = this.value.toUpperCase();" required>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="postcode" class="col-md-2 col-form-label text-md-right"><span class="required">* </span>Postcode</label>

                        <div class="col-md-4 input-group">
                          <input id="postcode" type="text" class="form-control @error('postcode') is-invalid @enderror" value="" name="postcode" required>
                        </div>

                        <label for="country" class="col-md-2 col-form-label text-md-right"><span class="required">* </span>Country</label>

                        <div class="col-md-4 input-group">
                          <input id="country" type="text" class="form-control @error('country') is-invalid @enderror" value="" name="country"  onkeyup="this.value = this.value.toUpperCase();" required>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="contact" class="col-md-2 col-form-label text-md-right">Contact Name</label>

                        <div class="col-md-4 input-group">
                          <input id="contact" type="text" class="form-control @error('contact') is-invalid @enderror" value=""  onkeyup="this.value = this.value.toUpperCase();" name="contact">
                        </div>

                        <label for="telephone" class="col-md-2 col-form-label text-md-right">Telephone</label>

                        <div class="col-md-4 input-group">
                          <input id="telephone" type="text" class="form-control @error('telephone') is-invalid @enderror" value="" name="telephone">
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="fax" class="col-md-2 col-form-label text-md-right">Fax</label>

                        <div class="col-md-4 input-group">
                          <input id="fax" type="text" class="form-control @error('fax') is-invalid @enderror" value="" name="fax"  >
                        </div>

                        <label for="email" class="col-md-2 col-form-label text-md-right">Email</label>

                        <div class="col-md-4 input-group">
                          <input id="email" type="text" class="form-control @error('email') is-invalid @enderror" value="" name="email"  >
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="remark" class="col-md-2 col-form-label text-md-right">Remark</label>

                        <div class="col-md-10 input-group">
                          <input id="remark" type="text" class="form-control @error('remark') is-invalid @enderror" value="" name="remark">
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="invoice_format" class="col-md-2 col-form-label text-md-right"><span class="required">* </span>Invoice Format</label>

                        <div class="col-md-10 input-group">
                          <select name="invoice_format" class="form-control input-sm" required>
    												<option value="C">[ C ] Carton</option>
    												<option value="S">[ S ] Size</option>
    											</select>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="credit_limit" class="col-md-2 col-form-label text-md-right">Credit Limit</label>

                        <div class="col-md-10 input-group">
                          <input id="credit_limit" type="text" class="form-control @error('credit_limit') is-invalid @enderror" value="" name="credit_limit"  >
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="term_day" class="col-md-2 col-form-label text-md-right">Term (Day)</label>

                        <div class="col-md-10 input-group">
                          <input id="term_day" type="text" class="form-control @error('term_day') is-invalid @enderror" value="" name="term_day"  >
                        </div>
                    </div>

                    <div class="form-group row">
                      <div class="col-md-2">

                      </div>
                      <div class="col-md-10 form-check" style="padding-left:35px;">
                        <input type="hidden" name="tax_exclusive" id="tax_exclusive" value="0">
                        <input type="checkbox" name="tax_exclusive" class="form-check-input" id="tax_exclusive" value="1">
                        <label class="form-check-label" for="tax_exclusive">Tax Exclusive</label>
                      </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-md-2">
                        </div>
                        <div class="col-md-4">
                            <button type="submit" class="btn btn-success form-control"><i class="fa fa-user-plus"></i> Save</button>
                        </div>
                        <div class="col-md-4">
                            <a href="{{ route('shipping.index') }}" class="btn btn-danger form-control"><i class="fa fa-user-times"></i> Cancel</a>
                        </div>
                        <div class="col-md-2">
                        </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-3">
            <div class="card">
                <div class="card-header">Task List</div>

                <div class="card-body">
                  @if(count($task) === 0)
                    <a href="{{ route('task.create') }}" style="text-decoration:none;"><i class="fas fa-plus-circle"></i> Add Task</a>
                  @else
                    @foreach ($task as $row)
                      <a href="#" style="text-decoration: none;">{{ $row->subject }}</a>
                      <hr>
                    @endforeach
                    <a href="{{ route('task.index') }}" style="text-decoration: none;float: right;"><i class="fas fa-chevron-circle-right"></i> Full Task List</a>
                  @endif
                </div>
            </div>
          </div>
    </div>
</div>

@endsection

@section('script')
<script type="text/javascript">
$(document).ready(function() {

  window.setTimeout(function() {
   $(".alert").fadeTo(500, 0).slideUp(500, function(){
     $(this).remove();
   });
  }, 4000);

  const Toast = Swal.mixin({
    toast: true,
    position: 'bottom-end',
    showConfirmButton: false,
    timer: 5000
  });

  @if(\Session::has('error'))
    Toast.fire({
      type: 'error',
      title: '{{ \Session::get('error') }}'
    })
  @endif
});
</script>
@endsection
