@extends('layouts.app')

@section('headscript')
<script src="https://code.jquery.com/jquery-3.4.1.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.2.3/css/responsive.bootstrap4.min.css">
<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/responsive/2.2.3/js/dataTables.responsive.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/responsive/2.2.3/js/responsive.bootstrap4.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.6/js/dataTables.buttons.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.6/js/buttons.html5.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.6/js/buttons.print.min.js"></script>


@endsection

@section('style')
<style media="screen">
.dataTables_filter {
  text-align: right !important;
}
.header{
  color: #fff;
  background-color: #212529;
  border-color: #32383e;
}
.required{
  color: red;
}
</style>
@endsection

@section('content')
<div class="container">
  @if ($checkAdmin == 'admin')
    @if ($activeCount >= 1 || $countpriority >= 1)
      <div class="row justify-content-center" style="margin-bottom:20px;">
          <div class="col-md-12">
              <div class="card">
                  <div class="card-body">
                    @if($countpriority > 1)
                      <i class="fas fa-exclamation-triangle required"></i> <a href="{{ route('task.index') }}" style="text-decoration:none;"> <b style="color:black;">{{ $countpriority }} URGENT Task <span class="required">(Priority 5)</span> waiting to be resolved!</b></a>
                      <br>
                    @elseif($countpriority == 1)
                      @foreach ($priority as $tasknoti)
                        <i class="fas fa-exclamation-triangle required"></i> <b>URGENT: {{$tasknoti->subject}} <span class="required">(Priority {{$tasknoti->priority}})</span></b>
                        <br>
                      @endforeach
                    @else
                    @endif

                    @if($activeCount >= 1)
                      Pending system activation request : <a href="{{ route('user-activation') }}" style="text-decoration:none;">{{$activeCount}} User waiting</a>
                    @else

                    @endif
                  </div>
              </div>
          </div>
      </div>
    @else

    @endif

  @else

  @endif

    <div class="row">
          <div class="col-md-9">
            <div class="card">
              <div class="card-header">
                <h1>Transaction Page</h1>
              </div>
              <div class="card-body">
                <div>
                  <form class="col-md-12" action="/consignment/{{ $search->id }}" method="post">
                    @method('PATCH')
                    @csrf
                  <div class="form-group row">
                    <label for="cn_no" class="col-md-3 col-form-label text-md-right"><span class="required">* </span>Consignment No.</label>

                    <div class="col-md-4 input-group">
                      <input id="cn_no" type="text" class="form-control @error('cn_no') is-invalid @enderror" value="{{ $search->cn_no }}" name="cn_no" required readonly>
                      <div class="input-group-append">
                        <button toggle="#cn_no" type="submit" class="input-group-text btn btn-info" readonly> Search </button>
                      </div>
                    </div>
                    <div class="col-md-5" style="text-align: right !important;">
                      <a class="btn btn-primary" href="{{ route('consignment.create') }}"><i class="fa fa-plus"></i> Add New Consignment</a>
                    </div>
                  </div>

                  <div class="form-group row">
                      <label for="shipper_code" class="col-md-3 col-form-label text-md-right"><span class="required">* </span>Shipper Code</label>

                      <div class="col-md-9 input-group">
                        <input id="shipper_code" type="text" class="form-control @error('shipper_code') is-invalid @enderror" value="{{ $search->shipper_code }}" name="shipper_code" required readonly>
                      </div>
                  </div>

                  <div class="form-group row">
                      <label for="shipper_name" class="col-md-3 col-form-label text-md-right">Shipper Name</label>

                      <div class="col-md-9 input-group">
                        <input id="shipper_name" type="text" class="form-control @error('shipper_name') is-invalid @enderror" value="{{ $search->shipper_name }}" name="shipper_name" readonly>
                      </div>
                  </div>

                  <div class="form-group row">
                      <label for="receiver_name" class="col-md-3 col-form-label text-md-right"><span class="required">* </span>Receiver Name</label>

                      <div class="col-md-9 input-group">
                        <input id="receiver_name" type="text" class="form-control @error('receiver_name') is-invalid @enderror" value="{{ $search->receiver_name }}" name="receiver_name" required>
                      </div>
                  </div>

                  <div class="form-group row">
                      <label for="pod" class="col-md-3 col-form-label text-md-right">P.O.D</label>

                      <div class="col-md-4 input-group">
                        <div class="input-group date" id="pod" data-target-input="nearest">
                          <input type="text" class="form-control datetimepicker-input" data-target="#pod"/>
                          <div class="input-group-append" data-target="#pod" data-toggle="datetimepicker">
                            <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                          </div>
                        </div>
                      </div>
                  </div>

                  <div class="form-group row">
                      <label for="destination_code" class="col-md-3 col-form-label text-md-right"><span class="required">* </span>Destination Code</label>

                      <div class="col-md-4 input-group">
                        <input id="destination_code" type="text" class="form-control @error('destination_code') is-invalid @enderror" value="{{ $search->destination_code }}" name="destination_code" required>
                      </div>
                  </div>

                  <div class="form-group row">
                      <label for="destination_name" class="col-md-3 col-form-label text-md-right">Destination Name</label>

                      <div class="col-md-9 input-group">
                        <input id="destination_name" type="text" class="form-control @error('destination_name') is-invalid @enderror" value="{{ $destination_name }}" name="destination_name">
                      </div>
                  </div>

                  <div class="form-group row">
                      <label for="cn_date" class="col-md-3 col-form-label text-md-right">Date</label>

                      <div class="col-md-4 input-group">
                        <div class="input-group date" id="date" data-target-input="nearest">
                          <input type="text" class="form-control datetimepicker-input" data-target="#date"/>
                          <div class="input-group-append" data-target="#date" data-toggle="datetimepicker">
                            <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                          </div>
                        </div>
                      </div>
                  </div>

                </div>
              </div> <!-- end card-body -->
            </div>
          </div>
          <div class="col-md-3">
            <div class="card">
                <div class="card-header">Task List</div>

                <div class="card-body">
                  @if(count($task) === 0)
                    <a href="{{ route('task.create') }}" style="text-decoration:none;"><i class="fas fa-plus-circle"></i> Add Task</a>
                  @else
                    @foreach ($task as $row)
                      <a href="#" style="text-decoration: none;">{{ $row->subject }}</a>
                      <hr>
                    @endforeach
                    <a href="{{ route('task.index') }}" style="text-decoration: none;float: right;"><i class="fas fa-chevron-circle-right"></i> Full Task List</a>
                  @endif
                </div>
            </div>
          </div>
    </div> <!-- end row -->
    <br>
    <div class="row">
      <div class="col-md-9">
        <div class="card">
          <div class="card-body">
            <div>

              <div class="form-group row">
                <label for="quantity" class="col-md-3 col-form-label text-md-right">Quantity</label>

                <div class="col-md-3 input-group">
                  <input id="quantity" type="text" class="form-control @error('quantity') is-invalid @enderror" value="{{ $search->quantity }}" name="quantity">
                </div>

                <label for="weight" class="col-md-2 col-form-label text-md-right">Weight</label>

                <div class="col-md-3 input-group">
                  <input id="weight" type="text" class="form-control @error('weight') is-invalid @enderror" value="" name="weight">
                </div>
              </div>

              <div class="form-group row">
                <label for="measure" class="col-md-3 col-form-label text-md-right">Measure</label>

                <div class="col-md-3 input-group">
                  <select name="measure" class="form-control input-sm" id="measure">
                    <option value="">Please Select</option>
                    <option value="CTN" @if($search->measure == 'CTN') selected @endif >CTN</option>
                    <option value="M3" @if($search->measure == 'M3') selected @endif>M3</option>
                    <option value="PKT" @if($search->measure == 'PKT') selected @endif>PKT</option>
                  </select>
                </div>
              </div>

              <div class="form-group row cartonrate">
                <label for="carton_size" class="col-md-3 col-form-label text-md-right">Carton Size</label>

                <div class="col-md-3 input-group">
                  <input id="carton_size" type="text" class="form-control @error('carton_size') is-invalid @enderror" value="{{ $search->carton_size }}" name="carton_size">
                </div>

                <label for="carton_rate" class="col-md-2 col-form-label text-md-right">Carton Rate</label>

                <div class="col-md-3 input-group">
                  <input id="carton_rate" type="text" class="form-control @error('carton_rate') is-invalid @enderror" value="@if($search->carton_rate == '') 0.00 @else {{$search->carton_rate}} @endif" name="carton_rate" readonly>
                </div>
              </div>

              <div class="form-group row prate">
                <label for="p_size" class="col-md-3 col-form-label text-md-right">P Size</label>

                <div class="col-md-3 input-group">
                  <input id="p_size" type="text" class="form-control @error('p_size') is-invalid @enderror" value="{{ $search->p_size }}" name="p_size">
                </div>

                <label for="p_rate" class="col-md-2 col-form-label text-md-right">P Rate</label>

                <div class="col-md-3 input-group">
                  <input id="p_rate" type="text" class="form-control @error('p_rate') is-invalid @enderror calc_charge" value="@if($search->p_rate == '') 0.00 @else {{$search->p_rate}} @endif" name="p_rate" readonly>
                </div>
              </div>

              <div class="form-group row srate">
                <label for="s_size" class="col-md-3 col-form-label text-md-right">S Size</label>

                <div class="col-md-3 input-group">
                  <input id="s_size" type="text" class="form-control @error('s_size') is-invalid @enderror" value="{{ $search->s_size }}" name="s_size">
                </div>

                <label for="s_rate" class="col-md-2 col-form-label text-md-right">S Rate</label>

                <div class="col-md-3 input-group">
                  <input id="s_rate" type="text" class="form-control @error('s_rate') is-invalid @enderror" value="@if($search->s_rate == '') 0.00 @else {{$search->s_rate}} @endif" name="s_rate" readonly>
                </div>
              </div>

              <div class="form-group row mrate">
                <label for="m_size" class="col-md-3 col-form-label text-md-right">M Size</label>

                <div class="col-md-3 input-group">
                  <input id="m_size" type="text" class="form-control @error('m_size') is-invalid @enderror" value="{{ $search->m_size }}" name="m_size">
                </div>

                <label for="m_rate" class="col-md-2 col-form-label text-md-right">M Rate</label>

                <div class="col-md-3 input-group">
                  <input id="m_rate" type="text" class="form-control @error('m_rate') is-invalid @enderror" value="@if($search->m_rate == '') 0.00 @else {{$search->m_rate}} @endif" name="m_rate" readonly>
                </div>
              </div>

              <div class="form-group row brate">
                <label for="b_size" class="col-md-3 col-form-label text-md-right">B Size</label>

                <div class="col-md-3 input-group">
                  <input id="b_size" type="text" class="form-control @error('b_size') is-invalid @enderror" value="{{ $search->b_size }}" name="b_size">
                </div>

                <label for="b_rate" class="col-md-2 col-form-label text-md-right">B Rate</label>

                <div class="col-md-3 input-group">
                  <input id="b_rate" type="text" class="form-control @error('b_rate') is-invalid @enderror" value="@if($search->b_rate == '') 0.00 @else {{$search->b_rate}} @endif" name="b_rate" readonly>
                </div>
              </div>

              <div class="form-group row xlrate">
                <label for="xl_size" class="col-md-3 col-form-label text-md-right">XL Size</label>

                <div class="col-md-3 input-group">
                  <input id="xl_size" type="text" class="form-control @error('xl_size') is-invalid @enderror" value="{{ $search->xl_size }}" name="xl_size">
                </div>

                <label for="xl_rate" class="col-md-2 col-form-label text-md-right">XL Rate</label>

                <div class="col-md-3 input-group">
                  <input id="xl_rate" type="text" class="form-control @error('xl_rate') is-invalid @enderror" value="@if($search->xl_rate == '') 0.00 @else {{$search->xl_rate}} @endif" name="xl_rate" readonly>
                </div>
              </div>

              <div class="form-group row pktrate">
                <label for="pkt_size" class="col-md-3 col-form-label text-md-right">PKT Size</label>

                <div class="col-md-3 input-group">
                  <input id="pkt_size" type="text" class="form-control @error('pkt_size') is-invalid @enderror" value="{{ $search->pkt_size }}" name="pkt_size">
                </div>

                <label for="pkt_rate" class="col-md-2 col-form-label text-md-right">PKT Rate</label>

                <div class="col-md-3 input-group">
                  <input id="pkt_rate" type="text" class="form-control @error('pkt_rate') is-invalid @enderror" value="@if($search->pkt_rate == '' || $search->pkt_rate == ' ' ) 0.00 @else {{$search->pkt_rate}} @endif" name="pkt_rate" readonly>
                </div>
              </div>

              <div class="form-group row m3rate">
                <label for="m3_size" class="col-md-3 col-form-label text-md-right">M3 Size</label>

                <div class="col-md-3 input-group">
                  <input id="m3_size" type="text" class="form-control @error('m3_size') is-invalid @enderror" value="{{ $search->m3_size }}" name="m3_size">
                </div>

                <label for="m3_rate" class="col-md-2 col-form-label text-md-right">M3 Rate</label>

                <div class="col-md-3 input-group">
                  <input id="m3_rate" type="text" class="form-control @error('m3_rate') is-invalid @enderror" value="@if($search->m3_rate == '') 0.00 @else {{$search->m3_rate}} @endif" name="m3_rate" readonly>
                </div>
              </div>

              <div class="form-group row">
                <label for="other_charges" class="col-md-3 col-form-label text-md-right">Other Charges</label>

                <div class="col-md-3 input-group">
                  <input id="other_charges" type="text" class="form-control @error('other_charges') is-invalid @enderror" value="{{ $search->other_charges }}" name="other_charges">
                </div>

                <label for="other_amount" class="col-md-2 col-form-label text-md-right">Other Amount</label>

                <div class="col-md-3 input-group">
                  <input id="other_amount" type="text" class="form-control @error('other_amount') is-invalid @enderror" value="@if($search->other_amount == '') 0.00 @else {{$search->other_amount}} @endif" name="other_amount">
                </div>
              </div>

            </div>
          </div>
        </div>
      </div>
    </div> <!-- end row -->
    <br>
    <div class="row">
      <div class="col-md-9">
        <div class="card">
          <div class="card-body">
            <div>

              <div class="form-group row">
                  <label for="sub_amount" class="col-md-3 col-form-label text-md-right">Sub Amount</label>

                  <div class="col-md-9 input-group">
                    <input id="sub_amount" type="text" class="form-control @error('sub_amount') is-invalid @enderror" value="{{ $search->sub_amount }}" name="sub_amount">
                  </div>
              </div>

              <div class="form-group row">
                  <label for="gst_amount" class="col-md-3 col-form-label text-md-right">SST Amount</label>

                  <div class="col-md-9 input-group">
                    <input id="gst_amount" type="text" class="form-control @error('gst_amount') is-invalid @enderror" value="{{ $search->gst_amount }}" name="gst_amount">
                  </div>
              </div>

              <div class="form-group row">
                  <label for="total_amount" class="col-md-3 col-form-label text-md-right">Total Amount</label>

                  <div class="col-md-9 input-group">
                    <input id="total_amount" type="text" class="form-control @error('total_amount') is-invalid @enderror" value="{{ $search->total_amount }}" name="total_amount">
                  </div>
              </div>

              <div class="form-group row">
                <div class="col-md-2">
                </div>
                <div class="col-md-8 row">

                  <div class="col-md-4">
                    <button class="btn btn-success col-md-12" type="submit"><i class="fa fa-check" ></i> Save</button>
                  </div>
                </form> <!-- end form update -->

                <div class="col-md-4">
                  <a onclick="deleteData({{ $search->id }})" class="btn btn-danger form-control" style="color: white;"><i class="fa fa-trash"></i> Delete</a>
                </div>

                  <div class="col-md-4">
                    <a href="{{ route('consignment.index') }}" class="btn btn-secondary form-control"><i class="fas fa-redo-alt"></i> Clear</a>
                  </div>

                </div>
                <div class="col-md-2">
                </div>
              </div>

            </div>
          </div>
        </div>
      </div>
    </div> <!-- end row -->
</div>

@endsection

@section('script')
<script type="text/javascript">

function getNum(val) {
  if (isNaN(val)){
    return '0.00';
  }
  else {
    return parseFloat(val).toFixed(2);
  }
}

function calculate(){
  var subtotal;
  var sst_value = {{ $sst }}/100;
  var total;

  var carton = document.getElementById('carton_size').value*document.getElementById('carton_rate').value;
  var p = document.getElementById('p_size').value*document.getElementById('p_rate').value;
  var s = document.getElementById('s_size').value*document.getElementById('s_rate').value;
  var m = document.getElementById('m_size').value*document.getElementById('m_rate').value;
  var b = document.getElementById('b_size').value*document.getElementById('b_rate').value;
  var xl = document.getElementById('xl_size').value*document.getElementById('xl_rate').value;
  var pkt = document.getElementById('pkt_size').value*document.getElementById('pkt_rate').value;
  var m3 = document.getElementById('m3_size').value*document.getElementById('m3_rate').value;
  var other = 1*document.getElementById('other_amount').value;

  subtotal = getNum(carton + p + s + m + b + xl + pkt + m3 + other);
  document.getElementById('sub_amount').value=subtotal;

  sst = getNum(document.getElementById('sub_amount').value*sst_value);
  document.getElementById('gst_amount').value=sst;

  total = getNum(parseFloat(document.getElementById('sub_amount').value)+parseFloat(document.getElementById('gst_amount').value));
  document.getElementById('total_amount').value=total;
}

$(document).ready(function() {
  $("#carton_size, #p_size, #s_size, #m_size, #b_size, #xl_size, #pkt_size, #m3_size").each(function(){
    $(this).keyup(function(){
      calculate();
    });
  });
});

function checkotheramount(){
  if($('#other_amount').val() == '' || $('#other_amount').val() == '0' || $('#other_amount').val() == '0.00'){
    $('#p_size').attr('readonly', false);
    $('#s_size').attr('readonly', false);
    $('#m_size').attr('readonly', false);
    $('#b_size').attr('readonly', false);
    $('#xl_size').attr('readonly', false);
    $('#pkt_size').attr('readonly', false);
    $('#carton_size').attr('readonly', false);
    $('#m3_size').attr('readonly', false);

    calculate();
  } else{
    $('#p_size').attr('readonly', true);
    $('#s_size').attr('readonly', true);
    $('#m_size').attr('readonly', true);
    $('#b_size').attr('readonly', true);
    $('#xl_size').attr('readonly', true);
    $('#pkt_size').attr('readonly', true);
    $('#carton_size').attr('readonly', true);
    $('#m3_size').attr('readonly', true);
    document.getElementById('p_size').value='0';
    document.getElementById('s_size').value='0';
    document.getElementById('m_size').value='0';
    document.getElementById('b_size').value='0';
    document.getElementById('xl_size').value='0';
    document.getElementById('pkt_size').value='0';
    document.getElementById('carton_size').value='0';
    document.getElementById('m3_size').value='0';

    calculate();
  }
}

$("#other_amount").keyup(function(){
  checkotheramount()
});

$(function () {
  $('#pod').datetimepicker({
      defaultDate: "{{ $search->pod }}",
      format: 'DD/MM/YYYY'
  });

  $('#date').datetimepicker({
      defaultDate: "{{ $search->cn_date }}",
      format: 'DD/MM/YYYY'
  });
});

</script>
<script>
  function deleteData(id) {
      Swal.fire({
          title: 'Are you sure?',
          text: "You won't be able to revert this!",
          type: "warning",
          confirmButtonColor: '#2fa360',
          cancelButtonColor: '#d33',
          showCancelButton: !0,
          confirmButtonText: "Yes, delete it!",
          cancelButtonText: "No, cancel!"
      }).then(function (e) {

          if (e.value === true) {
              var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');

              $.ajax({
                  type: 'POST',
                  url: "{{ url('consignment')}}" + '/' + id,
                  data: {'_token' : CSRF_TOKEN, '_method' : 'DELETE'},
                  dataType: 'JSON',
                  success: function (results) {
                      if (results.success === true) {
                          Swal.fire(
                            "Done!",results.message,"success"
                          ).then(function() {
                            window.location = "{{ url('consignment')}}";
                          });
                      } else {
                          swal("Error!", results.message, "error");
                      }
                  }
              });

          } else {
              e.dismiss;
          }
      }, function (dismiss) {
          return false;
      })
  }
</script>
@endsection
