@extends('layouts.app')

@section('headscript')
<script src="https://code.jquery.com/jquery-3.4.1.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.2.3/css/responsive.bootstrap4.min.css">
<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/responsive/2.2.3/js/dataTables.responsive.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/responsive/2.2.3/js/responsive.bootstrap4.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.6/js/dataTables.buttons.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.6/js/buttons.html5.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.5.6/js/buttons.print.min.js"></script>
@endsection

@section('style')
<style media="screen">
.dataTables_filter {
  text-align: left !important;
}
.header{
  color: #fff;
  background-color: #212529;
  border-color: #32383e;
}
.required{
  color: red;
}
</style>
@endsection

@section('content')
<div class="container">
  @if ($checkAdmin == 'admin')
    @if ($activeCount >= 1 || $countpriority >= 1)
      <div class="row justify-content-center" style="margin-bottom:20px;">
          <div class="col-md-12">
              <div class="card">
                  <div class="card-body">
                    @if($countpriority > 1)
                      <i class="fas fa-exclamation-triangle required"></i> <a href="{{ route('task.index') }}" style="text-decoration:none;"> <b style="color:black;">{{ $countpriority }} URGENT Task <span class="required">(Priority 5)</span> waiting to be resolved!</b></a>
                      <br>
                    @elseif($countpriority == 1)
                      @foreach ($priority as $tasknoti)
                        <i class="fas fa-exclamation-triangle required"></i> <b>URGENT: {{$tasknoti->subject}} <span class="required">(Priority {{$tasknoti->priority}})</span></b>
                        <br>
                      @endforeach
                    @else
                    @endif

                    @if($activeCount >= 1)
                      Pending system activation request : <a href="{{ route('user-activation') }}" style="text-decoration:none;">{{$activeCount}} User waiting</a>
                    @else

                    @endif
                  </div>
              </div>
          </div>
      </div>
    @else

    @endif

  @else

  @endif

    <div class="row">
          <div class="col-md-9">
            <div class="card">
              <div class="card-header">
                <h1>Create New Task</h1>
              </div>
              <div class="card-body">
                <div>
                  <form method="POST" action="{{ route('task.store') }}" id="taskform">
                    @csrf

                    <div class="row">
                      <div class="form-group col-md-8">
                        <label for="subject" class="col-form-label text-md-right"><span class="required">* </span>Subject</label>

                        <div class="input-group">
                          <input id="subject" type="text" class="form-control @error('subject') is-invalid @enderror" value="" name="subject" required>
                        </div>
                      </div>
                      <div class="form-group col-md-4">
                        <label for="deadline" class="col-form-label text-md-right"><span class="required">* </span>Deadline</label>

                        <div class="input-group">
                          <div class="input-group date" id="deadline" data-target-input="nearest">
                            <input name="deadline" type="text" class="form-control datetimepicker-input" data-target="#deadline"/>
                            <div class="input-group-append" data-target="#deadline" data-toggle="datetimepicker">
                              <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div class="row">
                      <div class="form-group col-md-12">
                        <label for="description" class="col-form-label text-md-right">Description</label>

                        <div class="input-group">
                          <textarea class="form-control" id="description" rows="3" name="description" form="taskform"></textarea>
                        </div>
                      </div>
                    </div>

                    <div class="row">
                      <div class="form-group col-md-12">
                        <label for="remarks" class="col-form-label text-md-right">Remarks</label>

                        <div class="input-group">
                          <input id="remarks" type="text" class="form-control @error('remarks') is-invalid @enderror" value="" name="remarks">
                        </div>
                      </div>
                    </div>

                    <div class="row">
                      <div class="form-group col-md-4">
                        <label for="assign_to">Assign To</label>

                        <div class="input-group">
                          <select name="assign_to" class="form-control input-sm" id="assign_to">
                            <option value="" selected="true" disabled="disabled">Please Select</option>
                            @foreach($assign as $row)
                              <option value="{{ $row->username }}">{{ $row->firstname }} {{ $row->lastname }}</option>
                            @endforeach
                          </select>
                        </div>
                      </div>

                      <div class="form-group col-md-4">
                        <label for="request_by">Request By</label>

                        <input type="request_by" class="form-control" id="request_by" name="request_by" value="{{ strtoupper(Auth::user()->username) }}">
                      </div>

                      <div class="form-group col-md-4">
                        <label for="priority"><span class="required">* </span>Priority</label>

                        <div class="input-group">
                          <select name="priority" class="form-control input-sm" id="priority">
                            <option value="5">5 - Urgent</option>
                            <option value="4">4 - Important</option>
                            <option value="3">3 - Normal</option>
                            <option value="2">2 - Normal</option>
                            <option value="1">1 - Less Important</option>
                          </select>
                        </div>
                      </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-md-2">
                        </div>
                        <div class="col-md-4">
                            <button type="submit" class="btn btn-success form-control"><i class="fa fa-user-plus"></i> Save</button>
                        </div>
                        <div class="col-md-4">
                            <a href="{{ route('call.index') }}" class="btn btn-danger form-control"><i class="fa fa-user-times"></i> Cancel</a>
                        </div>
                        <div class="col-md-2">
                        </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-3">
            <div class="card">
                <div class="card-header">Task List</div>

                <div class="card-body">
                  @if(count($task) === 0)
                    <a href="{{ route('task.create') }}" style="text-decoration:none;"><i class="fas fa-plus-circle"></i> Add Task</a>
                  @else
                    @foreach ($task as $row)
                      <a href="#" style="text-decoration: none;">{{ $row->subject }}</a>
                      <hr>
                    @endforeach
                    <a href="{{ route('task.index') }}" style="text-decoration: none;float: right;"><i class="fas fa-chevron-circle-right"></i> Full Task List</a>
                  @endif
                </div>
            </div>
          </div>
    </div>
</div>

@endsection

@section('script')
<script type="text/javascript">
$(document).ready(function() {

  $(function () {
    $('#deadline').datetimepicker({
        defaultDate: moment(new Date()),
        format: 'DD/MM/YYYY'
    });
  });

const Toast = Swal.mixin({
  toast: true,
  position: 'bottom-end',
  showConfirmButton: false,
  timer: 5000
});

@if(\Session::has('error'))
  Toast.fire({
    type: 'error',
    title: '{{ \Session::get('error') }}'
  })
@elseif(\Session::has('success'))
  Toast.fire({
    type: 'success',
    title: '{{ \Session::get('success') }}'
  })
@endif
});
</script>
@endsection
