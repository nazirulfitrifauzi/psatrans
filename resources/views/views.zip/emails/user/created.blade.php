@component('mail::message')
# Account Created!

Your account has been created by the admin.

Your temporary password is : psa@123! <br>

Before login to your account, click the button below and reset your password to your liking.

<b style="color:red;">* Never login with the temporary password! *</b>

@component('mail::button', ['url' => config('app.urlchangepassword'), 'color' => 'success'])
Reset Password Now
@endcomponent

Thanks,<br>
{{ config('app.name') }}
@endcomponent
