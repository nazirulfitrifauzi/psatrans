@component('mail::message')
# Registration Approved!

Your request to register has been approved by the admin.

@component('mail::button', ['url' => config('app.url'), 'color' => 'success'])
Login Now
@endcomponent

Thanks,<br>
{{ config('app.name') }}
@endcomponent
