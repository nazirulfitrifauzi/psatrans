<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class shipping extends Model
{
  protected $table = 'shipping';

  protected $guarded = [];

  public $timestamps = false;
}
