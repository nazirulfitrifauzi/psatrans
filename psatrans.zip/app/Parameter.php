<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class parameter extends Model
{
  protected $table = 'parameter';

  protected $guarded = [];

  public $timestamps = false;
}
