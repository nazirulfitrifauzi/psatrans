<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class destination extends Model
{
  protected $table = 'destination';

  protected $guarded = [];

  public $timestamps = false;
}
