<?php

/* @var $factory \Illuminate\Database\Eloquent\Factory */

use App\CallRemark;
use Faker\Generator as Faker;

$factory->define(CallRemark::class, function (Faker $faker) {
    return [
        //
    ];
});
